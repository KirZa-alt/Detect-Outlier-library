from setuptools import setup, find_packages

setup(
    name='pandas-outliers',
    version='1.0.0',
    description='Add .outliers() method to pandas DataFrame for easy outlier detection',
    author='Kiran Hamza',
    packages=find_packages(),
    install_requires=['pandas', 'numpy', 'scipy', 'scikit-learn'],
)
